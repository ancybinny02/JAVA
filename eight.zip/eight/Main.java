import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        NetflixCollection netflixCollection = new NetflixCollection();

        // Adding movies to the collection
        netflixCollection.addMovie(new Movie("Inception", "Sci-Fi", 2010));
        netflixCollection.addMovie(new Movie("The Shawshank Redemption", "Drama", 1994));
        netflixCollection.addMovie(new Movie("The Dark Knight", "Action", 2008));

        // Displaying all movies
        System.out.println("All Movies:");
        netflixCollection.getAllMovies().forEach(System.out::println);

        // Displaying movies by genre
        System.out.println("\nAction Movies:");
        netflixCollection.getMoviesByGenre("Action").forEach(System.out::println);

        // Searching for a movie by title
        String searchTitle = "Inception";
        Movie foundMovie = netflixCollection.getMovieByTitle(searchTitle);
        if (foundMovie != null) {
            System.out.println("\nFound Movie: " + foundMovie);
        } else {
            System.out.println("\nMovie not found: " + searchTitle);
        }
    }
}