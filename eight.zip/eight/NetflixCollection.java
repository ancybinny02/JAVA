import java.util.ArrayList;
import java.util.List;


// NetflixCollection class representing a collection of Netflix movies
class NetflixCollection {
    private List<Movie> movies;

    public NetflixCollection() {
        movies = new ArrayList<>();
    }

    public void addMovie(Movie movie) {
        movies.add(movie);
    }

    public List<Movie> getAllMovies() {
        return new ArrayList<>(movies); // Return a copy of the list to prevent external modification
    }

    public List<Movie> getMoviesByGenre(String genre) {
        List<Movie> genreMovies = new ArrayList<>();
        for (Movie movie : movies) {
            if (movie.getGenre().equalsIgnoreCase(genre)) {
                genreMovies.add(movie);
            }
        }
        return genreMovies;
    }

    public Movie getMovieByTitle(String title) {
        for (Movie movie : movies) {
            if (movie.getTitle().equalsIgnoreCase(title)) {
                return movie;
            }
        }
        return null; // Movie not found
    }

    @Override
    public String toString() {
        return "NetflixCollection{" +
                "movies=" + movies +
                '}';
    }
}