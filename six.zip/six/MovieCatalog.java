import java.util.ArrayList;
import java.util.List;

public class MovieCatalog<T extends Movie> {
    private List<T> movies;

    public MovieCatalog() {
        this.movies = new ArrayList<>();
    }

    public void addMovie(T movie) {
        movies.add(movie);
    }

    public void displayMovies() {
        for (T movie : movies) {
            System.out.println(movie);
        }
    }
}
