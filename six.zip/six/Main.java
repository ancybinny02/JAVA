public class Main {
    public static void main(String[] args) {
        MovieCatalog<Movie> catalog = new MovieCatalog<>();

        Movie movie1 = new Movie("Inception", 2010);
        Movie movie2 = new Movie("The Matrix", 1999);

        catalog.addMovie(movie1);
        catalog.addMovie(movie2);

        System.out.println("All Movies:");
        catalog.displayMovies();
    }
}
