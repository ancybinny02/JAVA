import netflixmovies.Movie;
import netflixmovies.NetflixMovie;

public class Main {
    public static void main(String[] args) {
        // Creating a NetflixMovie object
        Movie movie = new NetflixMovie("Inception");

        // Using Movie interface methods
        movie.play();
        movie.pause();
        movie.stop();
        System.out.println("Movie Title: " + movie.getTitle());
    }
}
