package netflixmovies;

public interface Movie {
    void play();
    void pause();
    void stop();
    String getTitle();
}
