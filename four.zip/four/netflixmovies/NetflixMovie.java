package netflixmovies;

public class NetflixMovie implements Movie {
    private String title;

    public NetflixMovie(String title) {
        this.title = title;
    }

    public void play() {
        System.out.println("Playing: " + title);
    }

    public void pause() {
        System.out.println("Paused: " + title);
    }

    public void stop() {
        System.out.println("Stopped: " + title);
    }

    public String getTitle() {
        return title;
    }
}
